<script>
    window.REQUIRED_CODE_ERROR_MESSAGE = 'Please choose a country code';

    window.EMAIL_INVALID_MESSAGE = window.SMS_INVALID_MESSAGE = "Zadali jste naplatnou adresu. Upravte ji tak, aby byla spravně.";

    window.REQUIRED_ERROR_MESSAGE = "Toto pole musíte vyplnit. ";

    window.GENERIC_INVALID_MESSAGE = "Zadali jste naplatnou adresu. Upravte ji tak, aby byla spravně.";




    window.translation = {
        common: {
            selectedList: '{quantity} list selected',
            selectedLists: '{quantity} lists selected'
        }
    };

    var AUTOHIDE = Boolean(0);
</script>
<script src="https://sibforms.com/forms/end-form/build/main.js"></script>